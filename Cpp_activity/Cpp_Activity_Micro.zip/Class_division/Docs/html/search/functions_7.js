var searchData=
[
  ['sensor',['Sensor',['../class_sensor.html#a342d6d11ef572c8cba92cb76fb1a294b',1,'Sensor::Sensor()'],['../class_sensor.html#aa84aad87186b00eb99dd93033bc0cb30',1,'Sensor::Sensor(const std::string &amp;name)']]]
];
