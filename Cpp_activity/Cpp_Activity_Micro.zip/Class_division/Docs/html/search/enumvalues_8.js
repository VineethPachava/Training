var searchData=
[
  ['msgpack',['msgpack',['../namespacenlohmann_1_1detail.html#aa554fc6a11519e4f347deb25a9f0db40ac40d516627022a54003ac2b74a82688a',1,'nlohmann::detail']]]
];
