var searchData=
[
  ['cbor',['cbor',['../namespacenlohmann_1_1detail.html#aa554fc6a11519e4f347deb25a9f0db40aaf9de350d652f0c9055ddab514bd23ea',1,'nlohmann::detail']]]
];
