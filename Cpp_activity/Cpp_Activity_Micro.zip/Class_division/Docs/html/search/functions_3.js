var searchData=
[
  ['magnetometer',['Magnetometer',['../classsensor_1_1_magnetometer.html#a09d5d8674a21e70460745081ac759d87',1,'sensor::Magnetometer::Magnetometer()'],['../classsensor_1_1_magnetometer.html#a30b9846b3bbecf844e10845f47ff0bf5',1,'sensor::Magnetometer::Magnetometer(double x, double y, double z)']]],
  ['main',['main',['../main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]]
];
