var searchData=
[
  ['m_5fid',['m_id',['../class_sensor.html#a3d1ebe0e05e5d75604330a70d3acf9e5',1,'Sensor']]],
  ['m_5fname',['m_name',['../class_sensor.html#a364a2c3d5e77d1af61f2532a130c2836',1,'Sensor']]],
  ['magnetometer',['Magnetometer',['../classsensor_1_1_magnetometer.html',1,'sensor::Magnetometer'],['../classsensor_1_1_magnetometer.html#a09d5d8674a21e70460745081ac759d87',1,'sensor::Magnetometer::Magnetometer()'],['../classsensor_1_1_magnetometer.html#a30b9846b3bbecf844e10845f47ff0bf5',1,'sensor::Magnetometer::Magnetometer(double x, double y, double z)']]],
  ['magnetometer_2ecpp',['magnetometer.cpp',['../magnetometer_8cpp.html',1,'']]],
  ['magnetometer_2eh',['magnetometer.h',['../magnetometer_8h.html',1,'']]],
  ['main',['main',['../main_8cpp.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cpp']]],
  ['main_2ecpp',['main.cpp',['../main_8cpp.html',1,'']]]
];
