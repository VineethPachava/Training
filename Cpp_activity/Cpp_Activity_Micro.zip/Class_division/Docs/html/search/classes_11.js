var searchData=
[
  ['wide_5fstring_5finput_5fadapter',['wide_string_input_adapter',['../classnlohmann_1_1detail_1_1wide__string__input__adapter.html',1,'nlohmann::detail']]]
];
