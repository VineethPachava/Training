var searchData=
[
  ['roll',['roll',['../classsensor_1_1_accelerometer.html#a63e28e79c1b08471c86f163033b04c5d',1,'sensor::Accelerometer']]],
  ['rollpitchyaw',['RollPitchYaw',['../classsensor_1_1_accelerometer.html#af6581f59b9f71cabfa36a46d177deb5f',1,'sensor::Accelerometer::RollPitchYaw()'],['../classsensor_1_1_magnetometer.html#af6581f59b9f71cabfa36a46d177deb5f',1,'sensor::Magnetometer::RollPitchYaw()'],['../namespacesensor.html#a8d403ba02d81030a8c321487632d6dfd',1,'sensor::RollPitchYaw()']]]
];
