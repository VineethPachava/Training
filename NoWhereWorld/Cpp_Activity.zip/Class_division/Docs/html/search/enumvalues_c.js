var searchData=
[
  ['string',['string',['../namespacenlohmann_1_1detail.html#a1ed8fc6239da25abcaf681d30ace4985ab45cffe084dd3d20d928bee85e7b0f21',1,'nlohmann::detail']]]
];
