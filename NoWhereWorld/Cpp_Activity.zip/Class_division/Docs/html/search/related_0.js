var searchData=
[
  ['rollpitchyaw',['RollPitchYaw',['../classsensor_1_1_accelerometer.html#af6581f59b9f71cabfa36a46d177deb5f',1,'sensor::Accelerometer::RollPitchYaw()'],['../classsensor_1_1_magnetometer.html#af6581f59b9f71cabfa36a46d177deb5f',1,'sensor::Magnetometer::RollPitchYaw()']]]
];
