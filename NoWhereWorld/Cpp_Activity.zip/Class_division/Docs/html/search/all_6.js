var searchData=
[
  ['operator_2d',['operator-',['../classsensor_1_1_g_p_s.html#a5d2f338838b59c6e980ff96bf5bc8087',1,'sensor::GPS']]]
];
