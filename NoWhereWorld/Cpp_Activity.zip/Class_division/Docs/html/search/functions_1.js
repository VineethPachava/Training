var searchData=
[
  ['gps',['GPS',['../classsensor_1_1_g_p_s.html#aee655f2d2f29485e622e75a38d15420c',1,'sensor::GPS::GPS()'],['../classsensor_1_1_g_p_s.html#a14837a509a3f16ebdd2f2ba5088f9b3f',1,'sensor::GPS::GPS(std::string latitude, std::string longitude)']]]
];
