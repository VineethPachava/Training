var searchData=
[
  ['uncvref_5ft',['uncvref_t',['../namespacenlohmann_1_1detail.html#a53a082eedad9f4729fcd8fed552a21f7',1,'nlohmann::detail']]]
];
