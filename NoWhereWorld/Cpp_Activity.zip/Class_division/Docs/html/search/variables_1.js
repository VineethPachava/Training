var searchData=
[
  ['m_5fid',['m_id',['../class_sensor.html#a3d1ebe0e05e5d75604330a70d3acf9e5',1,'Sensor']]],
  ['m_5fname',['m_name',['../class_sensor.html#a364a2c3d5e77d1af61f2532a130c2836',1,'Sensor']]]
];
