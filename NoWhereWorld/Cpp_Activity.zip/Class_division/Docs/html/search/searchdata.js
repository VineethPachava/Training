var indexSectionsWithContent =
{
  0: "acfglmoprs~",
  1: "agms",
  2: "s",
  3: "afgms",
  4: "aglmoprs~",
  5: "cm",
  6: "r",
  7: "gp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "related",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Friends",
  7: "Macros"
};

