var searchData=
[
  ['unflatten',['unflatten',['../classnlohmann_1_1basic__json.html#a74fa3ab2003f2f6f2b69deaafed9126d',1,'nlohmann::basic_json']]],
  ['update',['update',['../classnlohmann_1_1basic__json.html#a1cfa9ae5e7c2434cab4cfe69bffffe11',1,'nlohmann::basic_json::update(const_reference j)'],['../classnlohmann_1_1basic__json.html#a27921dafadb3bbefd180235ec763e3ea',1,'nlohmann::basic_json::update(const_iterator first, const_iterator last)']]]
];
